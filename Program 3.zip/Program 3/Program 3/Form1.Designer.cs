﻿namespace Program_3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.CalculateBTN = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.ShippingProviderResult = new System.Windows.Forms.Label();
            this.InitialContractPriceResult = new System.Windows.Forms.Label();
            this.CompanyDiscountResult = new System.Windows.Forms.Label();
            this.LengthDiscountResult = new System.Windows.Forms.Label();
            this.FinalPriceResult = new System.Windows.Forms.Label();
            this.ProviderComboBox = new System.Windows.Forms.ComboBox();
            this.BusinessComboBox = new System.Windows.Forms.ComboBox();
            this.ContractYearsTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(81, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Shipping Contract Calculator";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(110, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Provider:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(107, 95);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Business:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(73, 121);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Contract Length:";
            // 
            // CalculateBTN
            // 
            this.CalculateBTN.Location = new System.Drawing.Point(136, 165);
            this.CalculateBTN.Name = "CalculateBTN";
            this.CalculateBTN.Size = new System.Drawing.Size(75, 23);
            this.CalculateBTN.TabIndex = 4;
            this.CalculateBTN.Text = "Calculate";
            this.CalculateBTN.UseVisualStyleBackColor = true;
            this.CalculateBTN.Click += new System.EventHandler(this.CalculateBTN_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(66, 225);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(93, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Shipping Provider:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(55, 257);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(104, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Initial Contract Price:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(60, 289);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Company Discount:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(71, 321);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 13);
            this.label8.TabIndex = 8;
            this.label8.Text = "Length Discount:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(100, 353);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(59, 13);
            this.label9.TabIndex = 9;
            this.label9.Text = "Final Price:";
            // 
            // ShippingProviderResult
            // 
            this.ShippingProviderResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ShippingProviderResult.Location = new System.Drawing.Point(168, 220);
            this.ShippingProviderResult.Name = "ShippingProviderResult";
            this.ShippingProviderResult.Size = new System.Drawing.Size(121, 23);
            this.ShippingProviderResult.TabIndex = 10;
            this.ShippingProviderResult.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // InitialContractPriceResult
            // 
            this.InitialContractPriceResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.InitialContractPriceResult.Location = new System.Drawing.Point(168, 252);
            this.InitialContractPriceResult.Name = "InitialContractPriceResult";
            this.InitialContractPriceResult.Size = new System.Drawing.Size(121, 23);
            this.InitialContractPriceResult.TabIndex = 11;
            this.InitialContractPriceResult.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // CompanyDiscountResult
            // 
            this.CompanyDiscountResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CompanyDiscountResult.Location = new System.Drawing.Point(168, 284);
            this.CompanyDiscountResult.Name = "CompanyDiscountResult";
            this.CompanyDiscountResult.Size = new System.Drawing.Size(121, 23);
            this.CompanyDiscountResult.TabIndex = 12;
            this.CompanyDiscountResult.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LengthDiscountResult
            // 
            this.LengthDiscountResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LengthDiscountResult.Location = new System.Drawing.Point(168, 316);
            this.LengthDiscountResult.Name = "LengthDiscountResult";
            this.LengthDiscountResult.Size = new System.Drawing.Size(121, 23);
            this.LengthDiscountResult.TabIndex = 13;
            this.LengthDiscountResult.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // FinalPriceResult
            // 
            this.FinalPriceResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.FinalPriceResult.Location = new System.Drawing.Point(168, 348);
            this.FinalPriceResult.Name = "FinalPriceResult";
            this.FinalPriceResult.Size = new System.Drawing.Size(121, 23);
            this.FinalPriceResult.TabIndex = 14;
            this.FinalPriceResult.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ProviderComboBox
            // 
            this.ProviderComboBox.FormattingEnabled = true;
            this.ProviderComboBox.Items.AddRange(new object[] {
            ""});
            this.ProviderComboBox.Location = new System.Drawing.Point(168, 63);
            this.ProviderComboBox.Name = "ProviderComboBox";
            this.ProviderComboBox.Size = new System.Drawing.Size(121, 21);
            this.ProviderComboBox.TabIndex = 15;
            // 
            // BusinessComboBox
            // 
            this.BusinessComboBox.FormattingEnabled = true;
            this.BusinessComboBox.Location = new System.Drawing.Point(168, 92);
            this.BusinessComboBox.Name = "BusinessComboBox";
            this.BusinessComboBox.Size = new System.Drawing.Size(121, 21);
            this.BusinessComboBox.TabIndex = 16;
            // 
            // ContractYearsTextBox
            // 
            this.ContractYearsTextBox.Location = new System.Drawing.Point(168, 121);
            this.ContractYearsTextBox.Name = "ContractYearsTextBox";
            this.ContractYearsTextBox.Size = new System.Drawing.Size(121, 20);
            this.ContractYearsTextBox.TabIndex = 17;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.ContractYearsTextBox);
            this.Controls.Add(this.BusinessComboBox);
            this.Controls.Add(this.ProviderComboBox);
            this.Controls.Add(this.FinalPriceResult);
            this.Controls.Add(this.LengthDiscountResult);
            this.Controls.Add(this.CompanyDiscountResult);
            this.Controls.Add(this.InitialContractPriceResult);
            this.Controls.Add(this.ShippingProviderResult);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.CalculateBTN);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button CalculateBTN;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label ShippingProviderResult;
        private System.Windows.Forms.Label InitialContractPriceResult;
        private System.Windows.Forms.Label CompanyDiscountResult;
        private System.Windows.Forms.Label LengthDiscountResult;
        private System.Windows.Forms.Label FinalPriceResult;
        private System.Windows.Forms.ComboBox ProviderComboBox;
        private System.Windows.Forms.ComboBox BusinessComboBox;
        private System.Windows.Forms.TextBox ContractYearsTextBox;
    }
}

