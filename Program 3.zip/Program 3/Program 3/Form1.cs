﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


/*
    * Grading ID:S2411
    * Program 3
    * 03/028/2024
    * CIS-199-50-4242
    * This program calculates the final price of a contract based on selected shipping provider, business, contract length, and applies corresponding discounts.
*/


namespace Program_3
{
    public partial class Form1 : Form
    {
        //Array of strings representing business names and shipping provider for selection.
        string[] BusinessNames = { "John’s Books", "Office Supplies", "J.B. Car Parts", "Gevalia Coffee", "Ceylon Tea", "My Footwear" };
        string[] ShippingProvider = { "USPS", "DHL", "FedEx", "UPS" };

        //Array of doubles representing discount rates
        double[] discountLookup = { 0.25, 0.20, 0.17, 0.15 };
        double[] ContractLengthLowend = { 0, 2, 5, 8 };
        double[] Saving = { 0, 5000, 10000, 15000 };

        // Constant integer representing the maximum and minimum number of contract years.
        const int MaxContractYears = 10;
        const int MinContractYears = 0;

        public Form1()
        {
            InitializeComponent();

            // Populate combo boxes with data
            foreach (string provider in ShippingProvider)
            {
                ProviderComboBox.Items.Add(provider);
            }

            foreach (string business in BusinessNames)
            {
                BusinessComboBox.Items.Add(business);
            }
        }

        private void CalculateBTN_Click(object sender, EventArgs e)
        {
            bool providerFound = false;
            bool businessFound = false;
            bool lengthFound = false;

            if (ProviderComboBox.SelectedIndex >= 0 && BusinessComboBox.SelectedIndex >= 0 &&
                int.TryParse(ContractYearsTextBox.Text, out int contractYears) && contractYears >= MinContractYears && contractYears <= MaxContractYears)
            {
                string selectedProvider = ProviderComboBox.Text;
                string selectedBusiness = BusinessComboBox.Text;
                double contractPrice = GetInitialPrice(selectedBusiness);

                // Sequential Search for provider
                double discount = 0;
                for (int i = 0; i < ShippingProvider.Length && !providerFound; i++)
                {
                    if (selectedProvider == ShippingProvider[i])
                    {
                        providerFound = true;
                        discount = discountLookup[i];
                    }
                }

                // Range Match for length discount
                double lengthDiscount = 0;
                int index = ContractLengthLowend.Length - 1;
                while (index >= 0 && !lengthFound)
                {
                    if (contractYears >= ContractLengthLowend[index])
                    {
                        lengthFound = true;
                        lengthDiscount = Saving[index];
                    }
                    index--;
                }

                //  company discount calculation
                double companyDiscount = contractPrice * discount;

                if (providerFound && lengthFound)
                {
                    double finalPrice = contractPrice - companyDiscount - lengthDiscount;
                    ShippingProviderResult.Text = selectedProvider;
                    InitialContractPriceResult.Text = contractPrice.ToString("C");
                    CompanyDiscountResult.Text = companyDiscount.ToString("C");
                    LengthDiscountResult.Text = lengthDiscount.ToString("C");
                    FinalPriceResult.Text = finalPrice.ToString("C");
                }
                else
                {
                    MessageBox.Show("Error: Provider or Contract Length not found.");
                }
            }
            else
            {
                if (ProviderComboBox.SelectedIndex < 0)
                    MessageBox.Show("Error: You Must Select a Provider");
                else if (BusinessComboBox.SelectedIndex < 0)
                    MessageBox.Show("Error: You Must Select a Business");
                else
                    MessageBox.Show("Error: You Must Provide Valid Contract Years [0,10]");
            }
        }

        private double GetInitialPrice(string businessName)
        {
            // Placeholder implementation, replace with actual logic
            switch (businessName)
            {
                case "John’s Books":
                    return 55000;
                case "Office Supplies":
                    return 87880;
                case "J.B. Car Parts":
                    return 65000;
                case "Gevalia Coffee":
                    return 90000;
                case "Ceylon Tea":
                    return 75500;
                case "My Footwear":
                    return 40550;
                default:
                    return 0; // Placeholder return value
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
