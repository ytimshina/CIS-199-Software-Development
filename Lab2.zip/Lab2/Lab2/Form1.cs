﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2
{
    /*
     * Grading ID:S2411
     * Lab2
     * 02/05/2024
     * CIS-199-50-4242
     *Lab 2 calculates the tip ammount based on the impute from user which is price per meal. 
    */



    public partial class Form1 : Form
    {

        private const double TIP_ONE = 0.15;
        private const double TIP_TWO = 0.18;
        private const double TIP_THREE = 0.20;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void CalculateBT_Click(object sender, EventArgs e)
        {
            double mealPrice;
            string enteredPrice = priceInput.Text;
            if (!double.TryParse(enteredPrice, out mealPrice))
            {
                MessageBox.Show("Invalid input. Please enter a valid number.");
                return;
            }

            mealPrice = double.Parse(enteredPrice);
            tipOneCalced.Text = calcTip(mealPrice, TIP_ONE).ToString("C");
            tipTwoCalced.Text = calcTip(mealPrice, TIP_TWO).ToString("C");
            tipThreeCalced.Text = calcTip(mealPrice, TIP_THREE).ToString("C");

        }
        private double calcTip(double price, double tip)
        {
            return price * tip;
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            tipOneLabel.Text = toPercent(TIP_ONE);
            tipTwoLabel.Text = toPercent(TIP_TWO);
            tipThreeLabel.Text = toPercent(TIP_THREE);

        }
        private string toPercent(double d)
        {
            return (d * 100) + "%";

        }

        private void tipThreeCalced_Click(object sender, EventArgs e)
        {

        }
    }
}
