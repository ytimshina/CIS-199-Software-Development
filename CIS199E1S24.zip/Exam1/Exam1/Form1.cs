﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exam1
{

    /*
    * Grading ID:S2411
    * Exam 1
    * 02/19/2024
    * CIS-199-50-4242
    * This program gives you which room you can afford based on the amount of money you are willing to spend 
   */

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void SubmitBTN_Click(object sender, EventArgs e)
        {
            double amount;

            if (double.TryParse(MoneyTextBox.Text, out amount))
            {
                if (amount >= 350)
                {
                    Answer.Text = "You can afford the Penthouse Suite";
                }
                else if (amount >= 300)
                {
                    Answer.Text = "You can afford the Executive Suite";
                }
                else if (amount >= 275)
                {
                    Answer.Text = "You can afford the Suite";
                }
                else if (amount >= 200)
                {
                    Answer.Text = "You can afford the Deluxe Single";
                }
                else if (amount >= 175)
                {
                    Answer.Text = "You can afford the Standard Double";
                }
                else if (amount >= 150)
                {
                    Answer.Text = "You can afford the Standard Single";
                }
                else
                {
                    Answer.Text = "You cannot afford a room";
                }
            }
            else
            {
                Answer.Text = "Please enter a valid number";
            }
        }

        private void Answer_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
