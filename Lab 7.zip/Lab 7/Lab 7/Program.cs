﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_7
{
    internal class Program
    {

        // Grading ID: S2411 
        // Lab 7
        // Due Date: 4/7/2024
        // Course Section: CIS-199-50-4242
        // Brief description: This program displays a solid square of asterisks with the side length equal to the positive integer entered by the user.


        static void Main(string[] args)
        {
            int numberOfStars;
            bool valid;

            do
            {
                Console.Write("Enter a number: ");
                valid = int.TryParse(Console.ReadLine(), out numberOfStars) && (numberOfStars > 0);
            } while (!valid);

            Console.WriteLine();
            ShowSquareOfStars(numberOfStars);
        }

        public static void ShowSquareOfStars(int numStars)
        {
            for (int rows = 1; rows <= numStars; ++rows)
            {
                for (int stars = 1; stars <= numStars; ++stars)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
        }
    }
}
