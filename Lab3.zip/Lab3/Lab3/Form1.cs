﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3
{

    /*
     * Grading ID:S2411
     * Lab3
     * 02/11/2024
     * CIS-199-50-4242
     *Lab 3 calculates the diameter, surface area and volume from the radius entered. 
    */
    public partial class Lab3 : Form
 
    {
        public Lab3()
        {
            InitializeComponent();
            this.btnCalc.Click += new System.EventHandler(this.button1_Click);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // radius of the sphere
            double radius = Convert.ToDouble(txtRadius.Text);

            // diameter of the sphere
            double diameter = 2 * radius;

            // surface area of the sphere
            double surfaceArea = 4.0 * Math.PI * Math.Pow(radius, 2.0);

            // volume of the sphere
            double volume = 4.0 / 3.0 * Math.PI * Math.Pow(radius, 3.0);

            txtDiameter.Text = Convert.ToString(diameter);
            txtSurfacearea.Text = Convert.ToString(surfaceArea);
            txtVolume.Text = Convert.ToString(volume);

        }

     
           
        

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Lab3_Load(object sender, EventArgs e)
        {
           
        }
    }
}
