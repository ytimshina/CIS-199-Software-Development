﻿namespace Lab3
{
    partial class Lab3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.radius = new System.Windows.Forms.Label();
            this.txtRadius = new System.Windows.Forms.TextBox();
            this.btnCalc = new System.Windows.Forms.Button();
            this.diameterL = new System.Windows.Forms.Label();
            this.surfaceAreaL = new System.Windows.Forms.Label();
            this.volumeL = new System.Windows.Forms.Label();
            this.txtDiameter = new System.Windows.Forms.Label();
            this.txtSurfacearea = new System.Windows.Forms.Label();
            this.txtVolume = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Image = global::Lab3.Properties.Resources.Sphere_and_Ball;
            this.pictureBox1.Location = new System.Drawing.Point(18, 33);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(119, 111);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // radius
            // 
            this.radius.AutoSize = true;
            this.radius.Location = new System.Drawing.Point(165, 36);
            this.radius.Name = "radius";
            this.radius.Size = new System.Drawing.Size(87, 13);
            this.radius.TabIndex = 1;
            this.radius.Text = "Radius of sphere";
            this.radius.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtRadius
            // 
            this.txtRadius.Location = new System.Drawing.Point(258, 33);
            this.txtRadius.Name = "txtRadius";
            this.txtRadius.Size = new System.Drawing.Size(100, 20);
            this.txtRadius.TabIndex = 2;
            // 
            // btnCalc
            // 
            this.btnCalc.Location = new System.Drawing.Point(258, 72);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(75, 23);
            this.btnCalc.TabIndex = 3;
            this.btnCalc.Text = "Calculate";
            this.btnCalc.UseVisualStyleBackColor = true;
            // 
            // diameterL
            // 
            this.diameterL.AutoSize = true;
            this.diameterL.Location = new System.Drawing.Point(35, 176);
            this.diameterL.Name = "diameterL";
            this.diameterL.Size = new System.Drawing.Size(49, 13);
            this.diameterL.TabIndex = 4;
            this.diameterL.Text = "Diameter";
            // 
            // surfaceAreaL
            // 
            this.surfaceAreaL.AutoSize = true;
            this.surfaceAreaL.Location = new System.Drawing.Point(15, 208);
            this.surfaceAreaL.Name = "surfaceAreaL";
            this.surfaceAreaL.Size = new System.Drawing.Size(72, 13);
            this.surfaceAreaL.TabIndex = 5;
            this.surfaceAreaL.Text = "Surface  Area";
            // 
            // volumeL
            // 
            this.volumeL.AutoSize = true;
            this.volumeL.Location = new System.Drawing.Point(42, 241);
            this.volumeL.Name = "volumeL";
            this.volumeL.Size = new System.Drawing.Size(42, 13);
            this.volumeL.TabIndex = 6;
            this.volumeL.Text = "Volume";
            // 
            // txtDiameter
            // 
            this.txtDiameter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDiameter.Location = new System.Drawing.Point(90, 176);
            this.txtDiameter.Name = "txtDiameter";
            this.txtDiameter.Size = new System.Drawing.Size(100, 23);
            this.txtDiameter.TabIndex = 7;
            // 
            // txtSurfacearea
            // 
            this.txtSurfacearea.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSurfacearea.Location = new System.Drawing.Point(90, 207);
            this.txtSurfacearea.Name = "txtSurfacearea";
            this.txtSurfacearea.Size = new System.Drawing.Size(100, 23);
            this.txtSurfacearea.TabIndex = 8;
            // 
            // txtVolume
            // 
            this.txtVolume.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtVolume.Location = new System.Drawing.Point(90, 240);
            this.txtVolume.Name = "txtVolume";
            this.txtVolume.Size = new System.Drawing.Size(100, 23);
            this.txtVolume.TabIndex = 9;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Image = global::Lab3.Properties.Resources.Sphere_and_Ball;
            this.pictureBox2.Location = new System.Drawing.Point(239, 208);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(119, 111);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 10;
            this.pictureBox2.TabStop = false;
            // 
            // Lab3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 361);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.txtVolume);
            this.Controls.Add(this.txtSurfacearea);
            this.Controls.Add(this.txtDiameter);
            this.Controls.Add(this.volumeL);
            this.Controls.Add(this.surfaceAreaL);
            this.Controls.Add(this.diameterL);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.txtRadius);
            this.Controls.Add(this.radius);
            this.Controls.Add(this.pictureBox1);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.Name = "Lab3";
            this.Text = "Lab3";
            this.Load += new System.EventHandler(this.Lab3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label radius;
        private System.Windows.Forms.TextBox txtRadius;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Label diameterL;
        private System.Windows.Forms.Label surfaceAreaL;
        private System.Windows.Forms.Label volumeL;
        private System.Windows.Forms.Label txtDiameter;
        private System.Windows.Forms.Label txtSurfacearea;
        private System.Windows.Forms.Label txtVolume;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}

