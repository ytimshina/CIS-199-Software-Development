﻿namespace Program_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NameLabel = new System.Windows.Forms.Label();
            this.TypeOfProcedureLabel = new System.Windows.Forms.Label();
            this.DurationLabel = new System.Windows.Forms.Label();
            this.MaterialNeededLabel = new System.Windows.Forms.Label();
            this.StaffNeededLabel = new System.Windows.Forms.Label();
            this.SeniorCitizenLabel = new System.Windows.Forms.Label();
            this.QuoteNameLabel = new System.Windows.Forms.Label();
            this.QuoteProcedureLabel = new System.Windows.Forms.Label();
            this.QuoteDurationLabel = new System.Windows.Forms.Label();
            this.QuoteTotalCostLabel = new System.Windows.Forms.Label();
            this.GetQuoteBTN = new System.Windows.Forms.Button();
            this.NameTextBox = new System.Windows.Forms.TextBox();
            this.TypeOfProcedureTextBox = new System.Windows.Forms.TextBox();
            this.DurationTextBox = new System.Windows.Forms.TextBox();
            this.MaterialNeededTextBox = new System.Windows.Forms.TextBox();
            this.StaffNeededTextBox = new System.Windows.Forms.TextBox();
            this.SeniorCitizenTextBox = new System.Windows.Forms.TextBox();
            this.QuoteNameResults = new System.Windows.Forms.Label();
            this.QuoteProcedureResults = new System.Windows.Forms.Label();
            this.QuoteDurationResults = new System.Windows.Forms.Label();
            this.QuoteTotalCostResults = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Location = new System.Drawing.Point(12, 67);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(35, 13);
            this.NameLabel.TabIndex = 0;
            this.NameLabel.Text = "Name";
            this.NameLabel.Click += new System.EventHandler(this.NameLabel_Click);
            // 
            // TypeOfProcedureLabel
            // 
            this.TypeOfProcedureLabel.AutoSize = true;
            this.TypeOfProcedureLabel.Location = new System.Drawing.Point(12, 93);
            this.TypeOfProcedureLabel.Name = "TypeOfProcedureLabel";
            this.TypeOfProcedureLabel.Size = new System.Drawing.Size(97, 13);
            this.TypeOfProcedureLabel.TabIndex = 1;
            this.TypeOfProcedureLabel.Text = "Type Of Procedure";
            this.TypeOfProcedureLabel.Click += new System.EventHandler(this.TypeOfProcedureLabel_Click);
            // 
            // DurationLabel
            // 
            this.DurationLabel.AutoSize = true;
            this.DurationLabel.Location = new System.Drawing.Point(12, 119);
            this.DurationLabel.Name = "DurationLabel";
            this.DurationLabel.Size = new System.Drawing.Size(47, 13);
            this.DurationLabel.TabIndex = 2;
            this.DurationLabel.Text = "Duration";
            // 
            // MaterialNeededLabel
            // 
            this.MaterialNeededLabel.AutoSize = true;
            this.MaterialNeededLabel.Location = new System.Drawing.Point(12, 145);
            this.MaterialNeededLabel.Name = "MaterialNeededLabel";
            this.MaterialNeededLabel.Size = new System.Drawing.Size(85, 13);
            this.MaterialNeededLabel.TabIndex = 3;
            this.MaterialNeededLabel.Text = "Material Needed";
            // 
            // StaffNeededLabel
            // 
            this.StaffNeededLabel.AutoSize = true;
            this.StaffNeededLabel.Location = new System.Drawing.Point(12, 171);
            this.StaffNeededLabel.Name = "StaffNeededLabel";
            this.StaffNeededLabel.Size = new System.Drawing.Size(67, 13);
            this.StaffNeededLabel.TabIndex = 4;
            this.StaffNeededLabel.Text = "StaffNeeded";
            // 
            // SeniorCitizenLabel
            // 
            this.SeniorCitizenLabel.AutoSize = true;
            this.SeniorCitizenLabel.Location = new System.Drawing.Point(12, 197);
            this.SeniorCitizenLabel.Name = "SeniorCitizenLabel";
            this.SeniorCitizenLabel.Size = new System.Drawing.Size(71, 13);
            this.SeniorCitizenLabel.TabIndex = 5;
            this.SeniorCitizenLabel.Text = "Senior Citizen";
            // 
            // QuoteNameLabel
            // 
            this.QuoteNameLabel.AutoSize = true;
            this.QuoteNameLabel.Location = new System.Drawing.Point(12, 266);
            this.QuoteNameLabel.Name = "QuoteNameLabel";
            this.QuoteNameLabel.Size = new System.Drawing.Size(35, 13);
            this.QuoteNameLabel.TabIndex = 6;
            this.QuoteNameLabel.Text = "Name";
            // 
            // QuoteProcedureLabel
            // 
            this.QuoteProcedureLabel.AutoSize = true;
            this.QuoteProcedureLabel.Location = new System.Drawing.Point(11, 312);
            this.QuoteProcedureLabel.Name = "QuoteProcedureLabel";
            this.QuoteProcedureLabel.Size = new System.Drawing.Size(56, 13);
            this.QuoteProcedureLabel.TabIndex = 7;
            this.QuoteProcedureLabel.Text = "Procedure";
            // 
            // QuoteDurationLabel
            // 
            this.QuoteDurationLabel.AutoSize = true;
            this.QuoteDurationLabel.Location = new System.Drawing.Point(11, 289);
            this.QuoteDurationLabel.Name = "QuoteDurationLabel";
            this.QuoteDurationLabel.Size = new System.Drawing.Size(47, 13);
            this.QuoteDurationLabel.TabIndex = 8;
            this.QuoteDurationLabel.Text = "Duration";
            // 
            // QuoteTotalCostLabel
            // 
            this.QuoteTotalCostLabel.AutoSize = true;
            this.QuoteTotalCostLabel.Location = new System.Drawing.Point(11, 335);
            this.QuoteTotalCostLabel.Name = "QuoteTotalCostLabel";
            this.QuoteTotalCostLabel.Size = new System.Drawing.Size(55, 13);
            this.QuoteTotalCostLabel.TabIndex = 9;
            this.QuoteTotalCostLabel.Text = "Total Cost";
            // 
            // GetQuoteBTN
            // 
            this.GetQuoteBTN.Location = new System.Drawing.Point(72, 374);
            this.GetQuoteBTN.Name = "GetQuoteBTN";
            this.GetQuoteBTN.Size = new System.Drawing.Size(75, 23);
            this.GetQuoteBTN.TabIndex = 10;
            this.GetQuoteBTN.Text = "Get Quote";
            this.GetQuoteBTN.UseVisualStyleBackColor = true;
            this.GetQuoteBTN.Click += new System.EventHandler(this.GetQuoteBTN_Click);
            // 
            // NameTextBox
            // 
            this.NameTextBox.Location = new System.Drawing.Point(113, 64);
            this.NameTextBox.Name = "NameTextBox";
            this.NameTextBox.Size = new System.Drawing.Size(100, 20);
            this.NameTextBox.TabIndex = 11;
            // 
            // TypeOfProcedureTextBox
            // 
            this.TypeOfProcedureTextBox.Location = new System.Drawing.Point(113, 90);
            this.TypeOfProcedureTextBox.Name = "TypeOfProcedureTextBox";
            this.TypeOfProcedureTextBox.Size = new System.Drawing.Size(100, 20);
            this.TypeOfProcedureTextBox.TabIndex = 12;
            // 
            // DurationTextBox
            // 
            this.DurationTextBox.Location = new System.Drawing.Point(113, 116);
            this.DurationTextBox.Name = "DurationTextBox";
            this.DurationTextBox.Size = new System.Drawing.Size(100, 20);
            this.DurationTextBox.TabIndex = 13;
            // 
            // MaterialNeededTextBox
            // 
            this.MaterialNeededTextBox.Location = new System.Drawing.Point(113, 142);
            this.MaterialNeededTextBox.Name = "MaterialNeededTextBox";
            this.MaterialNeededTextBox.Size = new System.Drawing.Size(100, 20);
            this.MaterialNeededTextBox.TabIndex = 14;
            // 
            // StaffNeededTextBox
            // 
            this.StaffNeededTextBox.Location = new System.Drawing.Point(113, 168);
            this.StaffNeededTextBox.Name = "StaffNeededTextBox";
            this.StaffNeededTextBox.Size = new System.Drawing.Size(100, 20);
            this.StaffNeededTextBox.TabIndex = 15;
            // 
            // SeniorCitizenTextBox
            // 
            this.SeniorCitizenTextBox.Location = new System.Drawing.Point(113, 194);
            this.SeniorCitizenTextBox.Name = "SeniorCitizenTextBox";
            this.SeniorCitizenTextBox.Size = new System.Drawing.Size(100, 20);
            this.SeniorCitizenTextBox.TabIndex = 16;
            // 
            // QuoteNameResults
            // 
            this.QuoteNameResults.Location = new System.Drawing.Point(113, 266);
            this.QuoteNameResults.Name = "QuoteNameResults";
            this.QuoteNameResults.Size = new System.Drawing.Size(100, 23);
            this.QuoteNameResults.TabIndex = 17;
            // 
            // QuoteProcedureResults
            // 
            this.QuoteProcedureResults.Location = new System.Drawing.Point(113, 289);
            this.QuoteProcedureResults.Name = "QuoteProcedureResults";
            this.QuoteProcedureResults.Size = new System.Drawing.Size(100, 23);
            this.QuoteProcedureResults.TabIndex = 18;
            this.QuoteProcedureResults.Click += new System.EventHandler(this.QuoteProcedureResults_Click);
            // 
            // QuoteDurationResults
            // 
            this.QuoteDurationResults.Location = new System.Drawing.Point(113, 312);
            this.QuoteDurationResults.Name = "QuoteDurationResults";
            this.QuoteDurationResults.Size = new System.Drawing.Size(100, 23);
            this.QuoteDurationResults.TabIndex = 19;
            // 
            // QuoteTotalCostResults
            // 
            this.QuoteTotalCostResults.Location = new System.Drawing.Point(113, 335);
            this.QuoteTotalCostResults.Name = "QuoteTotalCostResults";
            this.QuoteTotalCostResults.Size = new System.Drawing.Size(100, 23);
            this.QuoteTotalCostResults.TabIndex = 20;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.5F);
            this.label1.Location = new System.Drawing.Point(15, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(198, 26);
            this.label1.TabIndex = 21;
            this.label1.Text = "Bigg Smiles Dental";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label2.Location = new System.Drawing.Point(68, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 17);
            this.label2.TabIndex = 22;
            this.label2.Text = "Patient Info";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label3.Location = new System.Drawing.Point(87, 239);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 17);
            this.label3.TabIndex = 23;
            this.label3.Text = "Quote";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(232, 450);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.QuoteTotalCostResults);
            this.Controls.Add(this.QuoteDurationResults);
            this.Controls.Add(this.QuoteProcedureResults);
            this.Controls.Add(this.QuoteNameResults);
            this.Controls.Add(this.SeniorCitizenTextBox);
            this.Controls.Add(this.StaffNeededTextBox);
            this.Controls.Add(this.MaterialNeededTextBox);
            this.Controls.Add(this.DurationTextBox);
            this.Controls.Add(this.TypeOfProcedureTextBox);
            this.Controls.Add(this.NameTextBox);
            this.Controls.Add(this.GetQuoteBTN);
            this.Controls.Add(this.QuoteTotalCostLabel);
            this.Controls.Add(this.QuoteDurationLabel);
            this.Controls.Add(this.QuoteProcedureLabel);
            this.Controls.Add(this.QuoteNameLabel);
            this.Controls.Add(this.SeniorCitizenLabel);
            this.Controls.Add(this.StaffNeededLabel);
            this.Controls.Add(this.MaterialNeededLabel);
            this.Controls.Add(this.DurationLabel);
            this.Controls.Add(this.TypeOfProcedureLabel);
            this.Controls.Add(this.NameLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Label TypeOfProcedureLabel;
        private System.Windows.Forms.Label DurationLabel;
        private System.Windows.Forms.Label MaterialNeededLabel;
        private System.Windows.Forms.Label StaffNeededLabel;
        private System.Windows.Forms.Label SeniorCitizenLabel;
        private System.Windows.Forms.Label QuoteNameLabel;
        private System.Windows.Forms.Label QuoteProcedureLabel;
        private System.Windows.Forms.Label QuoteDurationLabel;
        private System.Windows.Forms.Label QuoteTotalCostLabel;
        private System.Windows.Forms.Button GetQuoteBTN;
        private System.Windows.Forms.TextBox NameTextBox;
        private System.Windows.Forms.TextBox TypeOfProcedureTextBox;
        private System.Windows.Forms.TextBox DurationTextBox;
        private System.Windows.Forms.TextBox MaterialNeededTextBox;
        private System.Windows.Forms.TextBox StaffNeededTextBox;
        private System.Windows.Forms.TextBox SeniorCitizenTextBox;
        private System.Windows.Forms.Label QuoteNameResults;
        private System.Windows.Forms.Label QuoteProcedureResults;
        private System.Windows.Forms.Label QuoteDurationResults;
        private System.Windows.Forms.Label QuoteTotalCostResults;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}

