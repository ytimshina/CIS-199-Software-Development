﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_1
{

    /*
     * Grading ID:S2411
     * Lab3
     * 02/13/2024
     * CIS-199-50-4242
     *Program 1 gets users inpute and calculates a quote bassed on the appropriate formulas. 
    */


    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            

        }

        private void GetQuoteBTN_Click(object sender, EventArgs e)
        {
            // Gets values from the text boxes 
            string name = NameTextBox.Text;
            string procedure = TypeOfProcedureTextBox.Text;
            double duration = Convert.ToDouble(DurationTextBox.Text);
            double materials = Convert.ToDouble(MaterialNeededTextBox.Text);
            int staff = Convert.ToInt32(StaffNeededTextBox.Text);
            int seniorCitizen = Convert.ToInt32(SeniorCitizenTextBox.Text);


            // Define constants
            double consultationFee = 100;
            double dentistRate = 50;
            double staffRate = 25;
            double materialCost = 0.10;

            // Base cost calculation
            double baseCost = consultationFee +
                  (duration * dentistRate) +
                  (duration * staff * staffRate) +
                  (materials * materialCost);

            // Check for senior discount    
            double discount = seniorCitizen > 0 ? baseCost * 0.1 : 0;
            // Apply discount
            double totalCost = baseCost - discount;

            // Displays Quote results
            QuoteNameResults.Text = name;
            QuoteProcedureResults.Text = procedure;
            QuoteDurationResults.Text = duration.ToString();
            QuoteTotalCostResults.Text = totalCost.ToString("C");

        }

        private void NameLabel_Click(object sender, EventArgs e)
        {

        }

        private void TypeOfProcedureLabel_Click(object sender, EventArgs e)
        {

        }

        private void QuoteProcedureResults_Click(object sender, EventArgs e)
        {

        }
    }
}
