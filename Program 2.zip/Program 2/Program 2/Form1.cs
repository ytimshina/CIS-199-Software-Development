﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_2
{

    /*
     * Grading ID:S2411
     * Program 2
     * 03/07/2024
     * CIS-199-50-4242
     *Program 2 gets users inpute and calculates points and adjusted points based on point value per excercise type while taking into account if the user has hydrted today or smoke.
    */




    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }



        private void button1_Click(object sender, EventArgs e)
        {
            // input validation
            if (String.IsNullOrWhiteSpace(NameTextBox.Text))
            {
                MessageBox.Show("Please enter your name");
                return;
            }

            int age;
            if (!Int32.TryParse(AgeTextBox.Text, out age) || age <= 0)
            {
                MessageBox.Show("Please enter a valid age");
                return;
            }

            if (ExcerciseTypeComboBox.SelectedIndex < 0)
            {
                MessageBox.Show("Please select an exercise type");
                return;
            }

            int duration;
            if (!Int32.TryParse(DurationTextBox.Text, out duration) || duration <= 0)
            {
                MessageBox.Show("Please enter a valid duration");
                return;
            }

            if (!HaveYouHydratedRadioButtonYes.Checked && !HaveYouHydratedRadioButtonNo.Checked)
            {
                MessageBox.Show("Please specify if you hydrated");
                return;
            }

            if (!DoYouSmokeRadioButtonYes.Checked && !DoYouSmokeRadioButtonNo.Checked)
            {
                MessageBox.Show("Please specify if you smoke");
                return;
            }

            // Calculating base points
            int basePoints = CalculateBasePoints();

            // Applying modifiers
            int finalPoints = ApplyModifiers(basePoints);

            // Display output
            CalculatedPoints.Text = basePoints.ToString();
            CalculatedAdjusted.Text = finalPoints.ToString();
        }

        private int CalculateBasePoints()
        {
            int points = 0;
            int duration = Int32.Parse(DurationTextBox.Text);

            switch (ExcerciseTypeComboBox.Text)
            {
                case "Running":
                    points = 10 * duration;
                    break;
                case "Weight Training":
                    points = 20 * duration;
                    break;
                case "Cycling":
                    points = 5 * duration;
                    break;
                case "Yoga":
                    points = 2 * duration;
                    break;
                case "Other":
                    points = 5 * duration;
                    break;
            }

            return points;
        }

        private int ApplyModifiers(int basePoints)
        {
            int finalPoints = basePoints;

            if (HaveYouHydratedRadioButtonYes.Checked)
            {
                finalPoints = (int)(basePoints * 1.1);
            }

            if (DoYouSmokeRadioButtonYes.Checked)
            {
                finalPoints = (int)(basePoints * 0.5);
            }

            return finalPoints;
        }

        private void HaveYouHydratedRadioButtonYes_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void DoYouSmokeRadioButtonYes_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void DoYouSmokeRadioButtonNo_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
