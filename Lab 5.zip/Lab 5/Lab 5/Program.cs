﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int temperature;
            int total = 0;
            int TempsNumb = 0;

            while (true)
            {
                //input prompt
                Console.Write("Enter temperatures from -20 to 130 (999 to quit): ");
                if (!int.TryParse(Console.ReadLine(), out temperature) || temperature < -20 || temperature > 130)
                {
                    Console.WriteLine("Valid temperatures range from -20 to 130. Please reenter temperature.");
                    continue;
                }

                total += temperature;
                TempsNumb++;

                //break
                if (temperature == 999)
                {
                    break;
                }


             

                //when 4 temps are entered the calculation is given
                if (TempsNumb >= 4)
                {
                    double average = (double)total / TempsNumb;
                    Console.WriteLine($"You entered {TempsNumb} valid temperatures");
                    Console.WriteLine($"The mean temperature is {average} degrees");
                }
            }

            
        }
    }
}
