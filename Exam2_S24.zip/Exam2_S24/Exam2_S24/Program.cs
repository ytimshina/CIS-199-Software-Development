﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam2_S24
{
    internal class Program
    {
        //Grading ID= S2411
        static void Main(string[] args)
        {
            int[] years = { 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023 };
            double[] infRate = { 0.70, 2.10, 2.10, 1.90, 2.30, 1.40, 7.00, 6.50, 3.40 };
            double[] changeInfRate = { 0.10, 1.4, 0.00, -0.20, 0.40, -0.90, 5.60, -0.50, -3.10 };

            Console.Write("Enter a year: ");
            string input = Console.ReadLine();

            if (int.TryParse(input, out int year))
            {
                int index = Array.IndexOf(years, year);
                if (index != -1)
                {
                    Console.WriteLine($"Inflation Rate for {year}: {infRate[index]:0.00}");
                    Console.WriteLine($"Change in Inflation Rate for {year}: {changeInfRate[index]:0.00}%");
                }
                else
                {
                    Console.WriteLine($"Sorry, no data for {year}");
                }
            }
            else
            {
                Console.WriteLine("Invalid year.");
            }
        }

    }
    }

