﻿using System;

namespace MenuApp
{

    /*
    * Grading ID:S2411
    * Program 4
    * 04/16/2024
    * CIS-199-50-4242
    * The program manages a restaurant menu, allowing adjustments to item prices and availability, and displays the menu before and after changes.
    */

    public class MenuItem
    {
        // Default values
        private const double DefaultPrice = 1.00;

        // Backing fields
        private double _price;
        private int _calories;
        private double _prepTime;
        private bool _available;

        // 6 parameters constructor 
        public MenuItem(string name, double price, int calories, double prepTime, int totalSales, bool availability)
        {
            Name = name;
            Price = price;
            Calories = calories;
            PrepTime = prepTime;
            TotalSales = totalSales;
            if (availability)
            {
                MakeAvailable();
            }
            else
            {
                MakeUnavailable();
            }
        }

        // Name of the menu item
        public string Name { get; }

        // Price of the menu item
        public double Price
        {
            get { return _price; }
            set { _price = value > 0 ? value : DefaultPrice; }
        }

        // Calories of the menu item
        public int Calories
        {
            get { return _calories; }
            set { _calories = value > 0 ? value : 100; }
        }

        // Preparation time of the menu item
        public double PrepTime
        {
            get { return _prepTime; }
            set { _prepTime = value > 0 ? value : 1.0; }
        }

        // Total sales of the menu item
        public int TotalSales { get; private set; }

        // Method to make the item available
        public void MakeAvailable()
        {
            _available = true;
        }

        // Method to make the item unavailable
        public void MakeUnavailable()
        {
            _available = false;
        }

        // Method to check if the item is available
        public bool IsAvailable()
        {
            return _available;
        }

        // Override ToString method to format the output
        public override string ToString()
        {
            return $"Name: {Name}{Environment.NewLine}" +
                   $"Price: {Price}{Environment.NewLine}" +
                   $"Calories: {Calories}{Environment.NewLine}" +
                   $"Prep Time: {PrepTime}{Environment.NewLine}" +
                   $"Total Sales: {TotalSales}{Environment.NewLine}" +
                   $"Availability: {_available}{Environment.NewLine}";
        }
    }
}
