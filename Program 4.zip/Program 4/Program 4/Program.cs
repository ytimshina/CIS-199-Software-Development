﻿using System;

namespace MenuApp
{

    /*
   * Grading ID:S2411
   * Program 4
   * 04/16/2024
   * CIS-199-50-4242
   * The program manages a restaurant menu, allowing adjustments to item prices and availability, and displays the menu before and after changes.
   */

    class MenuItemTest
    {
        static void Main(string[] args)
        {
            // Creating MenuItem objects
            MenuItem item1 = new MenuItem("Cheeseburger", 5.99, 600, 10, 50, true);
            MenuItem item2 = new MenuItem("Caesar Salad", 7.49, 350, 7.5, 30, true);
            MenuItem item3 = new MenuItem("Margherita Pizza", 9.99, 800, 15, 40, true);
            MenuItem item4 = new MenuItem("Chicken Alfredo", 12.99, 900, 20, 25, true);
            MenuItem item5 = new MenuItem("Chocklate Cake", 4.99, 500, 10, 60, false);

            MenuItem[] items = { item1, item2, item3, item4, item5 };

            // Displaying menu before changes
            Console.WriteLine("       Current Menu"      );
            Console.WriteLine("-------------------------");
            DisplayMenu(items);

            // Making changes to items
            item1.Price = 4.99;
            item2.MakeUnavailable();
            item4.Price = 13.99;
            item3.PrepTime = 13;
            item5.MakeAvailable();

            // Displaying menu after changes
            Console.WriteLine("      After Changes      ");
            Console.WriteLine("-------------------------");

            DisplayMenu(items);
        }

        // Method to display menu items
        public static void DisplayMenu(MenuItem[] items)
        {
            foreach (MenuItem item in items)
            {
                Console.WriteLine(item.ToString());
            }
        }
    }
}
